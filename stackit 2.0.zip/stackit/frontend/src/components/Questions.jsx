import { useEffect, useState } from "react";
import axios from "axios";

export default function QuestionsList() {
  const [questions, setQuestions] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/displayQ")
      .then(res => setQuestions(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 px-4">
      <div className="w-full max-w-2xl">
        <h2 className="text-3xl font-bold text-gray-800 text-center mb-6">
          All Questions
        </h2>
        {questions.length === 0 ? (
          <p className="text-center text-gray-500">No questions found.</p>
        ) : (
          questions.map(q => (
            <div key={q.id} className="bg-white p-5 rounded shadow mb-6">
              <p className="text-gray-700 leading-relaxed">
                <strong>{q.title}</strong>
                <br />
                {q.description}
              </p>
              <div className="mt-2">
                <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                  {q.tags}
                </span>
                <span className="ml-2 text-xs text-gray-400">
                  {new Date(q.created_at).toLocaleString()}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
      <a href="/" className="absolute top-4 left-4 text-blue-600 hover:underline">
        logout
      </a>
    </div>
  );
}