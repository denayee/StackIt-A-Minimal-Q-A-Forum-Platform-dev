export default function Home() {
  return (
    <>
      <header class="bg-white shadow-md py-4 px-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-blue-600">StackIt</h1>
        <div class="space-x-4">
          <a
            href="/userLogin"
            class="text-blue-600 border border-blue-600 px-4 py-1.5 rounded hover:bg-blue-600 hover:text-white transition"
          >
            Login
          </a>
          <a
            href="/registerUser"
            class="bg-blue-600 text-white px-4 py-1.5 rounded hover:bg-blue-700 transition"
          >
            Register
          </a>
        </div>
      </header>

      <main class="flex flex-col items-center justify-center min-h-screen px-4 text-center">
        <h2 class="text-4xl sm:text-5xl font-bold text-gray-800 mb-4">
          Ask Anything. Help Everyone.
        </h2>
        <p class="text-lg text-gray-600 max-w-xl mb-6">
          StackIt is a place to ask questions, share knowledge, and build your
          understanding. Whether you're stuck or curious, you're in the right
          place.
        </p>
        <a
          href="/registerUser"
          class="bg-blue-600 text-white px-6 py-3 rounded-md text-lg hover:bg-blue-700 transition"
        >
          Get Started
        </a>
      </main>
    </>
  );
}
