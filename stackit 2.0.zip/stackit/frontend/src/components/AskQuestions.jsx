import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AskQuestion() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async(e) => {
    e.preventDefault();
    const id = localStorage.getItem("user");

    const questionData = {
      id,
      title,
      description,
      tags: tags.split(",").map((tag) => tag.trim()),
    };

     await axios
      .post(
        "http://localhost:3000/question",
        { id : id,
          title : title,
          description : description,
          tags : tags,
        },
        {
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
        }
      )
.then((data) => {
        if (data.status == 200) {
          
          
          alert("quastion successful submitted");
          navigate("/questions");
       

             
          } else if (data != 200) {
          alert("Incorrect email or password");
        }
      });
    console.log("Submitting Question:", questionData);
    // Add your API call or state update logic here
  };

  return (
    <div className="min-h-screen bg-gray-50 flex justify-center items-start px-4 pt-10">
      <div className="bg-white p-8 rounded-md shadow-md w-full max-w-2xl">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">
          Ask a Question
        </h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Title
            </label>
            <input
              type="text"
              placeholder="e.g. How to use useEffect in React?"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              placeholder="Describe your problem in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows="6"
              required
              className="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            ></textarea>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tags
            </label>
            <input
              type="text"
              placeholder="e.g. React, useEffect, Hooks"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
          >
            Submit Question
          </button>
        </form>
      </div>
    </div>
  );
}

export default AskQuestion;
