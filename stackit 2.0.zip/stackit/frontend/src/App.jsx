import { useState } from "react";

function App() {
  return (
    <>
      <div className="text-amber-300">hello</div>
    </>
  );
}

export default App;
